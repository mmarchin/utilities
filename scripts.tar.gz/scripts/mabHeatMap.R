mabHeatMap <-  function(x, ...){
    min <- min(x)
    max <- max(x)
    yLabels <- rownames(x)
    xLabels <- colnames(x)
    title <-c()
                                        # check for additional function arguments
    if( length(list(...)) ){
      Lst <- list(...)
      if( !is.null(Lst$zlim) ){
        min <- Lst$zlim[1]
        max <- Lst$zlim[2]
      }
      if( !is.null(Lst$yLabels) ){
        yLabels <- c(Lst$yLabels)
      }
      if( !is.null(Lst$xLabels) ){
        xLabels <- c(Lst$xLabels)
      }
      if( !is.null(Lst$title) ){
        title <- Lst$title
      }
    }
                                        # check for null values
    if( is.null(xLabels) ){
      xLabels <- c(1:ncol(x))
    }
    if( is.null(yLabels) ){
      yLabels <- c(1:nrow(x))
    }

    layout(matrix(data=c(1,2), nrow=2, ncol=1), widths=c(1,1), heights=c(4,1))

    # Red and green range from 0 to 1 while Blue ranges from 1 to 0
    ColorRamp <- rgb(c(rep(0,25), seq(0,1,length=25)),   # Red
                     c(rep(0,25), seq(0,1,length=25)),   # Green
                     c(seq(1,0,length=25), rep(0,25)),   # Blue

                     
                       ) 
    ColorLevels <- seq(min, max, length=length(ColorRamp))

                                        # Reverse Y axis
    reverse <- nrow(x) : 1
    yLabels <- yLabels[reverse]
    x <- x[reverse,]

                                        # Data Map
    #par(mar = c(7,7,2.5,1))
    image(1:length(xLabels), 1:length(yLabels), t(x), col=ColorRamp, xlab="",
          ylab="", axes=FALSE, zlim=c(min,max))
    if( !is.null(title) ){
      title(main=title)
    }
    #axis(BELOW<-1, at=1:length(xLabels), labels=xLabels, cex.axis=0.7, las=2)
    #axis(LEFT <-2, at=1:length(yLabels), labels=yLabels, las= HORIZONTAL<-1,
         cex.axis=0.7)

                                        # Color Scale
    #par(mar = c(3,2.5,2.5,2))
     image(ColorLevels,1,
      matrix(data=ColorLevels, nrow=length(ColorLevels),ncol=1),
      col=ColorRamp,
      xlab="",ylab="",
      yaxt="n")

    layout(1)
  }
