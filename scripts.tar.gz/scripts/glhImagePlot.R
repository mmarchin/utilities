#Custom heatmap functions
CustomHeatmap <- function(x,col.grad){
  par(mar=c(1,3,3,3))
  image(t(x[nrow(x):1,]),axes=F,col=col.grad)

  x.row <- seq(from=0, to=1, length=ncol(x)) 
  y.col <- seq(from=1, to=0, length=nrow(x))

  lbl <- round(x,digits=2)

  for( i in 1:length(y.col) ) 
  { 
      text(x.row,y.col[i],labels=as.character(lbl[i,])) 
  }

  axis(3, at=seq(0,1,length.out=ncol(x)),
        labels=colnames(x), tick=F)
  axis(2, at=seq(0,1,length.out=nrow(x)),
        labels=rownames(x[nrow(x):1,]), tick=F)
}

colorBar <- function(n,col.grad){
  ColorLevels <- seq(min(n), max(n), length.out=length(col.grad))
  par(mar=c(3,3,1,3))
  image(matrix(ColorLevels,ncol=1),axes=F,col=col.grad)
  axis(1,at=seq(0,1,length.out=length(col.grad)),labels=round(ColorLevels,digits=2))
}

nf <- layout(matrix(c(1,2),nrow=2,ncol=1), heights=c(5,1), TRUE)
layout.show(nf)

new.colors <- colorpanel(10,"white","goldenrod1","sienna")

CustomHeatmap(x,new.colors)
colorBar(x,new.colors)
