library(seqLogo)

pfmplot <- function(pfmfile)
{
	pfm<-read.table(pfmfile);
	pwm<-array(dim=c(length(pfm[,1]),length(pfm[1,])));
	for( i in 1:length(pfm[1,]))
	{
		colsum<-sum(pfm[,i])

		for( j in 1:length(pfm[,1]))
		{
			pwm[j,i]<-pfm[j,i]/colsum;
		}
	}

	#pwm plot
	p<-makePWM(pwm);
	#pdf(paste(pfmfile,".pdf",sep=''),height=3,width=9)
	seqLogo(p);
	#dev.off();
}

#usage
#pdf("sequencelogos.pdf",height=3,width=9)
##pfm to pwm
#pfmfile<-"M00978.pfm"
#pfmplot(pfmfile);

#for(i in 1:10)
#{
#	filename=paste("M00978_scramble",i,".pfm",sep='');
#	pfmplot(filename);
#}
#dev.off()
