genomePlot<- function (x = NULL, xlim = NULL, probecolors = NULL, half.height = 0.25, plottitle= "", ylab = "") 
{
	nprobes <- length(x$labels)
    	charheight <- strheight("M", units = "inches")
	if (is.null(xlim)) 
	{
		xlim = range(c(x$starts, x$ends))
	}
	#probecolors <- sort(rep(rainbow(5),times=100))
	probecolors <- rainbow(40) 

	if (length(probecolors) < nprobes) 
	{
		probecolors <- rep(probecolors, length.out = nprobes)
	}

	bottom.margin <- 0.7
	left.margin<-2
	par(mai = c(bottom.margin,left.margin, charheight * 5, 0.1))
	par(omi = c(0.1, 0.1, 0.1, 0.1), xaxs = "i", yaxs = "i")
	plot(x$starts, 1:nprobes, xlim = c(min(x$starts),max(x$ends)), ylim = c(0.5, nprobes + 0.5), main=plottitle, xlab = "", ylab = ylab, type = "n", yaxt="n")
	box()
	#mtext(plottitle, 3, 2)
	topdown <- seq(nprobes, 1)
	axis(2, at = topdown, labels = x$labels, las = 2, cex.axis=.5)
	for (i in 1:nprobes) 
	{
		rect(x$starts[i], topdown[i] - half.height, x$ends[i], topdown[i] + half.height,border='gray', col = probecolors[30-floor(x$scores[i])])
		text(x$ends[i], topdown[i] - half.height, labels=x$scores[i], cex=.6)
	}
}
#x<-list(labels=c("probe1","probe2",'probe3','probe4'),starts=c(1000,200,350,150),ends=c(1100,250,700,900),scores=c(51,47,43,40))
#genomePlot(x)
